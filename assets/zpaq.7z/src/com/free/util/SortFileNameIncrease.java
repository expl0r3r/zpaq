package com.free.util;

import java.io.File;
import java.util.Comparator;

public class SortFileNameIncrease implements Comparator<File> {
	@Override
	public int compare(File p1, File p2) {
		return p1.getName().toLowerCase().compareTo(p2.getName().toLowerCase());
	}
}

