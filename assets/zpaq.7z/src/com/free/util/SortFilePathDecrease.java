package com.free.util;

import java.util.Comparator;

public class SortFilePathDecrease implements Comparator<FileInfo> {
	@Override
	public int compare(FileInfo p1, FileInfo p2) {
		return p2.path.compareTo(p1.path);
	}
}
