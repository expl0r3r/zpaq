package com.free.util;

import java.io.File;
import java.util.Comparator;

public class FileNameFirstSortingIncrease implements Comparator<File> {

	@Override
	public int compare(File f1, File f2) {
		if (f1.isFile() && f2.isFile() || f1.isDirectory() && f2.isDirectory()) {
			return f1.getAbsolutePath().toLowerCase().compareTo(f2.getAbsolutePath().toLowerCase());
		} else if (f1.isFile() && f2.isDirectory()) {
			return -1;
		} else {
			return 1;
		}
	}
}


