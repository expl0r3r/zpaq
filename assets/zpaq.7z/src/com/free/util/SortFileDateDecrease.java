package com.free.util;

import java.io.*;
import java.util.*;

public class SortFileDateDecrease implements Comparator<File> {
	@Override
	public int compare(File p1, File p2) {
		if (p1.isFile() && p2.isFile() || p1.isDirectory() && p2.isDirectory()) {
			long lastModified1 = p1.lastModified();
			long lastModified2 = p2.lastModified();
			if (lastModified1 < lastModified2) {
				return 1;
			} else if (lastModified1 > lastModified2) {
				return -1;
			} else {
				return p2.getName().toLowerCase().compareTo(p1.getName().toLowerCase());
			}
		} else if (p1.isFile() && p2.isDirectory()) {
			return 1;
		} else {
			return -1;
		}
	}
}
