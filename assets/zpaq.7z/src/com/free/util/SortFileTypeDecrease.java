package com.free.util;

import java.util.*;
import java.io.*;

public class SortFileTypeDecrease implements Comparator<File> {
	@Override
	public int compare(File p1, File p2) {
		if (p1.isFile() && p2.isFile()) {
			String namef1 = p1.getName().toLowerCase();
			int lastIndexOf = namef1.lastIndexOf(".");
			String type1 = (lastIndexOf >= 0 ? namef1.substring(lastIndexOf) : "");
			
			String namef2 = p2.getName().toLowerCase();
			lastIndexOf = namef2.lastIndexOf(".");
			String type2 = (lastIndexOf >= 0 ? namef2.substring(lastIndexOf) : "");
			
			if (type2.equals(type1)) {
				return namef2.compareTo(namef1);
			} else {
				return type2.compareTo(type1);
			}
		} else if (p1.isDirectory() && p2.isDirectory()) {
			return p2.getName().toLowerCase().compareTo(p1.getName().toLowerCase());
		} else if (p1.isFile() && p2.isDirectory()) {
			return 1;
		} else {
			return -1;
		}
	}
}

