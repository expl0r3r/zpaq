//package android.util;
//
//public class Log {
//	public static int d(String s, String s2) {
//		System.out.print(s);
//		System.out.print(": ");
//		System.out.println(s2);
//		return 0;
//	}
//
//	public static int i(String s, String s2) {
//		System.out.print(s);
//		System.out.print(": ");
//		System.out.println(s2);
//		return 0;
//	}
//
//	public static int e(String s, String s2) {
//		System.err.print(s);
//		System.err.print(": ");
//		System.err.println(s2);
//		return 0;
//	}
//
//	public static int w(String s, String s2) {
//		System.err.print(s);
//		System.err.print(": ");
//		System.err.println(s2);
//		return 0;
//	}
//
//	public static int d(String s, String s2, Throwable t) {
//		System.out.print(s);
//		System.out.print(": ");
//		System.out.println(s2);
//		t.printStackTrace();
//		return 0;
//	}
//
//	public static int i(String s, String s2, Throwable t) {
//		System.out.print(s);
//		System.out.print(": ");
//		System.out.println(s2);
//		t.printStackTrace();
//		return 0;
//	}
//
//	public static int e(String s, String s2, Throwable t) {
//		System.err.print(s);
//		System.err.print(": ");
//		System.err.println(s2);
//		t.printStackTrace();
//		return 0;
//	}
//
//	public static int w(String s, String s2, Throwable t) {
//		System.out.print(s);
//		System.out.print(": ");
//		System.out.println(s2);
//		t.printStackTrace();
//		return 0;
//	}
//}
