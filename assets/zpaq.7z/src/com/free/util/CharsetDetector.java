package com.free.util;

/*
 *  Copyright 2010 Georgios Migdos <cyberpython@gmail.com>.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *  under the License.
 */
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.*;
import org.mozilla.intl.chardet.*;
import com.free.util.*;

public class CharsetDetector {

    public static String[] mozillaDectect(File f, nsICharsetDetectionObserver observer) throws IOException {

		nsDetector det = new nsDetector(nsPSMDetector.ALL);
		// Set an observer...
		// The Notify() will be called when a matching charset is found.
		det.Init(observer);

		byte[] buf = FileUtil.readFileToMemory(f) ;
		int len = (int)f.length();
		boolean isAscii = true ;

		isAscii = det.isAscii(buf, len);

		// DoIt if non-ascii 
		if (!isAscii)
			det.DoIt(buf, len, false);

		det.DataEnd();

		if (isAscii) {
			System.out.println("CHARSET = ASCII");
			return new String[] {"ASCII"};
		} else {
			String prob[] = det.getProbableCharsets() ;
			for(int i=0; i<prob.length; i++) {
				System.out.println(prob[i]);
			}
			return prob;
		}
    }

	public Charset detectCharset(File f, String[] charsets) throws IOException {
		Charset charset = null;
		int i = 0;
		byte[] readFully = FileUtil.readFileToMemory(f);
		for (String charsetName : charsets) {
			charset = detectCharset(readFully, Charset.forName(charsetName));
			if (charset != null) {
				System.out.println(++i + ": " + charset);
				//break ;
			}
		}
		return charset;
	}
	private Charset detectCharset(byte[] readFully, Charset charset) {
		CharsetDecoder decoder = charset.newDecoder();
		decoder.reset();
		boolean identified = identify(readFully, decoder);
		if (identified) {
			return charset;
		} else {
			return null;
		}
	}

	private boolean identify( byte [] bytes, CharsetDecoder decoder) {
		try {
			decoder.decode(ByteBuffer.wrap(bytes));
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	public static Charset detectCharset(File f) throws IOException {

		SortedMap<String, Charset> charsets = Charset.availableCharsets();
		Set<String> names = charsets.keySet();
		String[] charsetsToBeTested = new String[names.size()];
		names.toArray(charsetsToBeTested);
		System.out.println("num of charsets " + charsetsToBeTested.length);
//		String[] charsetsToBeTested = {"UTF-8", 
//			"UTF-16", 
//			"UTF-16BE", 
//			"UTF-16LE", 
//			"UTF-32", 
//			"UTF-32BE", 
//			"UTF-32LE", 
//			"windows-1250", 
//			"windows-1251", 
//			"windows-1252", 
//			"windows-1253", 
//			"windows-1254", 
//			"windows-1255", 
//			"windows-1256", 
//			"windows-1257", 
//			"windows-1258", 
//			"ISO-8859-1", 
//			"ISO-8859-2", 
//			"ISO-8859-3", 
//			"ISO-8859-4", 
//			"ISO-8859-5", 
//			"ISO-8859-6", 
//			"ISO-8859-7", 
//			"ISO-8859-8", 
//			"ISO-8859-9", 
//			"ISO-8859-10", 
//			"ISO-8859-13", 
//			"ISO-8859-14", 
//			"ISO-8859-15", 
//			"x-JavaUnicode", 
//			"x-JavaUnicode2", 
//			"macintosh", 
//			"Shift_JIS", 
//			"EUC-JP", 
//			"EUC-KR", 
//			"Big5", 
//			"Big5-HKSCS", 
//			"x-UTF-16LE-BOM", 
//			"x-UTF16_OppositeEndian", 
//			"x-UTF16_PlatformEndian", 
//			"x-UTF32_OppositeEndian", 
//			"x-UTF32_PlatformEndian", 
//			"US-ASCII", 
//			"UTF-7"};

		CharsetDetector cd = new CharsetDetector();
		Charset charset = cd.detectCharset(f, charsetsToBeTested);
		return charset;
	}

	public static void main(String[] args) throws IOException  {
		File f = new File ("/storage/emulated/0/.com.free.searcher/storage/MicroSD/Searcher/Abhidhamma.7z/u-vdp6/vdp62-08.htm.converted.txt");
		detectCharset(f);
		mozillaDectect(f, null);
	}
}
