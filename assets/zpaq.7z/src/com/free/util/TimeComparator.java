package com.free.util;

import java.io.File;
import java.util.Comparator;

public class TimeComparator implements Comparator<File> {

	@Override
	public int compare(File o1, File o2) {
		return (int) (o1.lastModified() - o2.lastModified());
	}

}

